#!/usr/bin/env python3
"""
A simple HTTP server that allows users to upload a test document, view its contents,
and then upload an answers file.  It uses only Python's standard library so that it
can run without installing any third‑party packages.

Supported document formats for viewing:
  - Plain text files (.txt, .md) – displayed as UTF‑8 text.
  - PDF files (.pdf) – extracted using the `pdftotext` command if available.
  - Word documents (.docx) – extracted using the `docx2txt` command if available.

All uploaded files are saved in the `uploads/` directory.  Answer files are saved
in `uploads/answers/`.
"""

import os
import subprocess
import html
from http.server import HTTPServer, BaseHTTPRequestHandler

# Directory to store uploads
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'uploads')
ANSWERS_DIR = os.path.join(UPLOAD_DIR, 'answers')


def ensure_directories():
    """Ensure that the upload directories exist."""
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(ANSWERS_DIR, exist_ok=True)


def extract_text(file_path: str) -> str:
    """
    Attempt to extract text from the given file based on its extension.
    For unsupported types or extraction failures, return an appropriate message.

    :param file_path: Path to the uploaded file.
    :return: Extracted text or a message indicating extraction issues.
    """
    ext = file_path.rsplit('.', 1)[-1].lower() if '.' in file_path else ''
    try:
        if ext in ('txt', 'md'):
            # Read plain text files as UTF‑8
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                return f.read()
        elif ext == 'pdf':
            # Use pdftotext command to extract text
            result = subprocess.run(
                ['pdftotext', '-layout', file_path, '-'],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout
            else:
                return '[Unable to extract text from PDF file]'
        elif ext == 'docx':
            # Use docx2txt command to extract text
            # The '-' argument outputs to stdout on many systems
            result = subprocess.run(
                ['docx2txt', file_path, '-'],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout
            else:
                return '[Unable to extract text from DOCX file]'
        else:
            return f'[Unsupported file type: .{ext}]'
    except Exception as exc:
        return f'[Error while reading file: {exc}]'


def parse_multipart(body: bytes, boundary: bytes):
    """
    Parse a multipart/form-data body into a dictionary of fields.

    Each entry in the returned dictionary maps the form field name to a
    dictionary with keys:

        - 'filename': the filename provided by the client (if any)
        - 'content': the raw bytes of the uploaded content
    """
    results = {}
    boundary_delim = b'--' + boundary
    # Split the body on the boundary delimiter
    parts = body.split(boundary_delim)
    for part in parts:
        if not part or part == b'--' or part == b'--\r\n':
            continue
        # Each part begins with CRLF
        if part.startswith(b'\r\n'):
            part = part[2:]
        # Find the separator between headers and data
        header_end = part.find(b'\r\n\r\n')
        if header_end == -1:
            continue
        header_block = part[:header_end].decode('utf-8', errors='replace')
        data = part[header_end + 4:]
        # Remove trailing CRLF
        if data.endswith(b'\r\n'):
            data = data[:-2]
        headers = {}
        for line in header_block.split('\r\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                headers[key.strip().lower()] = value.strip()
        cd = headers.get('content-disposition', '')
        # Parse Content-Disposition parameters
        name = None
        filename = None
        for param in cd.split(';'):
            param = param.strip()
            if param.startswith('name='):
                name = param.split('=', 1)[1].strip('"')
            elif param.startswith('filename='):
                filename = param.split('=', 1)[1].strip('"')
        if name:
            results[name] = {
                'filename': filename,
                'content': data,
            }
    return results


class UploadHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the simple upload & answer app."""

    def _html(self, content: str) -> None:
        """Send an HTML response with the given content."""
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(content.encode('utf-8'))

    def do_GET(self):
        """Handle GET requests by serving the upload form."""
        if self.path != '/':
            # Only the root path is valid
            self.send_error(404, 'Not Found')
            return
        # Serve the initial form
        page = self.render_upload_form()
        self._html(page)

    def do_POST(self):
        """Handle POST requests for uploading and submitting answers."""
        content_type = self.headers.get('Content-Type', '')
        if not content_type.startswith('multipart/form-data'):
            self.send_error(415, 'Unsupported Media Type')
            return
        # Extract boundary from Content-Type header
        # Format: multipart/form-data; boundary=----WebKitFormBoundary...
        parts = content_type.split('boundary=')
        if len(parts) < 2:
            self.send_error(400, 'Bad Request')
            return
        boundary = parts[1].encode('utf-8')
        # Read the request body
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            self.send_error(411, 'Length Required')
            return
        body = self.rfile.read(length)
        # Parse multipart fields
        fields = parse_multipart(body, boundary)
        # Dispatch based on the path
        if self.path == '/upload':
            file_item = fields.get('file') if fields else None
            self.handle_file_upload(file_item)
        elif self.path == '/submit_answers':
            file_item = fields.get('file') if fields else None
            self.handle_answer_upload(file_item)
        else:
            self.send_error(404, 'Not Found')

    def handle_file_upload(self, file_item) -> None:
        """Handle the upload of the main document to be read."""
        # file_item should be a dict with 'filename' and 'content' keys
        if not file_item or not file_item.get('filename'):
            self._html('<h1>No file uploaded</h1>')
            return
        filename = os.path.basename(file_item['filename'])
        safe_name = filename.replace('/', '_').replace('\\', '_')
        file_path = os.path.join(UPLOAD_DIR, safe_name)
        # Save the uploaded file
        try:
            with open(file_path, 'wb') as f:
                f.write(file_item['content'])
        except Exception as exc:
            self._html(f'<h1>Failed to save file: {html.escape(str(exc))}</h1>')
            return

        # Extract text for display
        text = extract_text(file_path)
        escaped_text = html.escape(text)
        # Build response page with file content and answer upload form
        page = f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Uploaded Document</title>
</head>
<body>
  <h1>Uploaded Document: {html.escape(safe_name)}</h1>
  <h2>Contents</h2>
  <pre style="white-space: pre-wrap; border: 1px solid #ccc; padding: 1em; background: #f9f9f9;">{escaped_text}</pre>
  <h2>Upload Your Answers</h2>
  <form method="POST" action="/submit_answers" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <br><br>
    <input type="submit" value="Upload Answers">
  </form>
</body>
</html>
"""
        self._html(page)

    def handle_answer_upload(self, file_item) -> None:
        """Handle the upload of the answers file."""
        # file_item should be a dict with 'filename' and 'content'
        if not file_item or not file_item.get('filename'):
            self._html('<h1>No answer file uploaded</h1>')
            return
        filename = os.path.basename(file_item['filename'])
        safe_name = filename.replace('/', '_').replace('\\', '_')
        dest_path = os.path.join(ANSWERS_DIR, safe_name)
        # Save the answers file
        try:
            with open(dest_path, 'wb') as f:
                f.write(file_item['content'])
        except Exception as exc:
            self._html(f'<h1>Failed to save answers file: {html.escape(str(exc))}</h1>')
            return

        # Respond with a confirmation message
        page = f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Answers Uploaded</title>
</head>
<body>
  <h1>Thanks!</h1>
  <p>Your answers file <strong>{html.escape(safe_name)}</strong> has been uploaded successfully.</p>
  <p><a href="/">Upload another document</a></p>
</body>
</html>
"""
        self._html(page)

    @staticmethod
    def render_upload_form() -> str:
        """Return the HTML content for the initial upload form."""
        return """\
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Upload Document</title>
</head>
<body>
  <h1>Upload a Document to Read</h1>
  <form method="POST" action="/upload" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <br><br>
    <input type="submit" value="Upload Document">
  </form>
</body>
</html>
"""


def run(server_class=HTTPServer, handler_class=UploadHandler) -> None:
    """Start the HTTP server."""
    ensure_directories()
    server_address = ('', 8000)
    httpd = server_class(server_address, handler_class)
    print("Serving on port 8000...")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("Server stopped.")


if __name__ == '__main__':
    run()
