## Simple Upload & Answer App

This project is a minimal web application that allows users to:

1. **Upload a test document** (supported formats: **TXT**, **PDF**, and **DOCX**).
2. **Read the uploaded document** directly in the browser.
3. **Upload a separate answers file** after reviewing the document.

 The application is implemented using Python’s built‑in HTTP server library (`http.server`) along with a small custom parser for `multipart/form-data`, so it does not depend on any external frameworks.  Uploaded files are saved in the `uploads/` directory on the server.  When a test file is uploaded, the server extracts the text (using system tools for PDF and DOCX files) and displays it back to the user for reading.  After reviewing the document, the user can upload their answers as a second file.

### Running the App

To start the application locally:

```bash
# From the repository root
python app.py
```

Once the server is running, open a web browser and navigate to `http://localhost:8000`.  You will see a form to upload a test document.  After uploading, the file’s text will be displayed along with another form to upload your answers.

### How It Works

The app runs a simple HTTP server that handles two POST endpoints:

* **`/upload`** – accepts the test document.  The server stores the file in `uploads/` and tries to extract text based on the file extension:
  * `.txt` or `.md`: read as plain UTF‑8 text.
  * `.pdf`: uses the `pdftotext` tool (available on most systems) to extract text.
  * `.docx`: uses the `docx2txt` command‑line tool to extract text.
* **`/submit_answers`** – accepts the answers file and stores it in `uploads/answers/`.  After uploading, a confirmation message is shown.

If an unsupported file type is uploaded, the server will notify the user.

### Directory Structure

```
app.py            # Main HTTP server implementation
requirements.txt  # Lists external dependencies (empty because none are needed)
README.md         # This file
render            # Simple script to run the app
uploads/          # Directory where uploaded files are stored
```

### Notes

* Make sure the `pdftotext` and `docx2txt` utilities are installed on the server if you need to extract text from PDF or DOCX files.  They are commonly available on Linux systems.  If they aren’t available, PDF and DOCX uploads will still be saved, but their contents won’t be displayed.
* All uploaded files are stored on disk.  The server does not implement any authentication or security checks, so it should only be used in controlled environments.
